import "styled-components";

declare module "styled-componets" {
  export interface DefaultTheme {
    colors: { textColor: string; bgColor: string; accentColor: string };
  }
}
